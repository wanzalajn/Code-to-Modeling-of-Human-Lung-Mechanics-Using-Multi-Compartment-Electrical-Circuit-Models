# Lung Compartment Models: Simulation Code

Code accompanying the manuscript **"Modeling and Simulation of Human Lung
Mechanics Using Single to Multi-Compartment Electrical Circuit Models."**

This repository reproduces every simulated result, figure, and table in
the manuscript's Results section (Section IV-F onward): the pressure-,
flow-, and volume-time curves (Figures 5-7), the dynamic
compliance-resistance response (Figure 8), the predictive-accuracy
comparison (Table III), and the weighted-decision-matrix sensitivity
analysis (Figure 9 / Section IV-J).

## Important scope note

**No patient or clinical ventilator data are used anywhere in this
repository.** The multi-compartment (N = 10) model is used as an internal,
high-fidelity analytical reference. The single-, two-, and
three-compartment models are obtained by coarse-graining (parallel
aggregation of resistance, summation of compliance) groups of the ten
reference compartments, so that they are nested approximations of the
same underlying reference lung rather than independently fitted models.
All "predictive accuracy" results in the manuscript should be read as a
measure of internal model-order approximation quality against this
reference, not as validation against real physiological measurements.
See Section II-D and the Limitations in Section V of the manuscript for
the full discussion.

## Repository structure

```
lung_models/
├── README.md
├── requirements.txt
├── src/
│   ├── simulate.py                    # core model definitions + VCV solver
│   ├── generate_fig5_pressure.py      # Figure 5: pressure-time curves
│   ├── generate_fig6_flow.py          # Figure 6: flow-time curves
│   ├── generate_fig7_volume.py        # Figure 7: volume-time curves
│   ├── generate_fig8_compliance.py    # Figure 8: dynamic compliance-resistance
│   ├── compute_table3_accuracy.py     # Table III: RMSE/MAE/correlation vs. reference
│   ├── sensitivity_analysis.py        # decision-matrix scoring + sensitivity analysis
│   └── generate_fig_sensitivity.py    # Figure 9: sensitivity comparison figure
└── figures/                           # output directory (created automatically)
```

## Requirements

- Python >= 3.9
- Dependencies listed in `requirements.txt` (NumPy, Matplotlib)

Install with:

```bash
pip install -r requirements.txt
```

## Reproducing the manuscript's results

All scripts are run from inside `src/` and write their output to
`../figures/`.

```bash
cd src

# Core simulation sanity check (prints peak/plateau pressure and tidal
# volume for each model)
python simulate.py

# Figures 5-8
python generate_fig5_pressure.py
python generate_fig6_flow.py
python generate_fig7_volume.py
python generate_fig8_compliance.py

# Table III (predictive accuracy vs. the N=10 reference model)
python compute_table3_accuracy.py

# Decision-matrix sensitivity analysis (prints both scoring schemes'
# results to the console) and its comparison figure
python sensitivity_analysis.py
python generate_fig_sensitivity.py
```

## Model summary

| Model  | Free parameters (R, C, [R0]) | Role |
|--------|-------------------------------|------|
| Single | R, C (2 parameters) | Coarse-grained aggregate of all 10 reference compartments |
| Two    | R1, C1, R2, C2 (4 parameters) | Aggregate of reference units 1-5 and 6-10 |
| Three  | R0, R1, C1, R2, C2, R3, C3 (7 parameters, structurally) | Aggregate of reference units 1-4, 5-7, 8-10 |
| Multi (N=10) | 10 x (R, C) + R0 | High-fidelity reference model; not a real-time candidate |

Ventilation is simulated as genuine volume-controlled ventilation: a
prescribed constant inspiratory flow, a zero-flow inspiratory hold
(during which compartments may still redistribute volume internally),
and passive, pressure-controlled expiration to PEEP. See `simulate.py`
for the full derivation and implementation, which follows the governing
equations of Sections IV-B through IV-E of the manuscript.

## Decision-matrix sensitivity analysis

`sensitivity_analysis.py` implements two independent, fully documented
ways of scoring the three qualitative decision-matrix criteria (Clinical
Applicability, Ease of Parameter Estimation, Model Stability):

- **Illustrative scheme**: fixed expert-judgment scores (see the
  `ILLUSTRATIVE_*` constants at the top of the file).
- **Rigorous scheme**: formula-derived proxies --  Model Stability from
  the eigenvalue stiffness ratio of each model's linear state matrix;
  Ease of Parameter Estimation from the structural free-parameter count
  of the general model definition; Clinical Applicability from the
  coefficient of variation of each model's compartmental time constants.

The two schemes disagree on which model is favored by the weighted
decision matrix; this disagreement, and its implications, are discussed
in full in Section IV-J of the manuscript. The multi-compartment (N=10)
model is deliberately excluded from this ranking, since it is the
reference model and scoring it for accuracy against itself would be
circular.

## Citation

If you use this code, please cite the manuscript (full citation to be
added upon publication).

## License

MIT License (see `LICENSE`).
