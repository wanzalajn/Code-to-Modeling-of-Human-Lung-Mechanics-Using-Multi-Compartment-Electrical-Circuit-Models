"""
Generate the sensitivity-analysis comparison figure (illustrative vs.
rigorous scoring of the qualitative decision-matrix criteria).

Usage:
    python generate_fig_sensitivity.py

Output:
    ../figures/fig_sensitivity_comparison.png
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

from sensitivity_analysis import (
    MODEL_NAMES, build_scores, weighted_totals, monte_carlo_sensitivity, BASE_WEIGHTS,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

mpl.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.edgecolor": "0.3", "axes.grid": True,
    "grid.color": "0.85", "grid.linewidth": 0.6,
    "font.size": 10, "axes.titlesize": 10.5, "axes.titleweight": "bold",
})


def main():
    colors = {"single": "#4c72b0", "two": "#dd8452", "three": "#55a868"}

    illus_scores = build_scores("illustrative")
    illus_base = weighted_totals(illus_scores, BASE_WEIGHTS)
    illus_mc_centered = monte_carlo_sensitivity(illus_scores, centered=True)
    illus_mc_uniform = monte_carlo_sensitivity(illus_scores, centered=False)

    rig_scores = build_scores("rigorous")
    rig_base = weighted_totals(rig_scores, BASE_WEIGHTS)
    rig_mc_centered = monte_carlo_sensitivity(rig_scores, centered=True)
    rig_mc_uniform = monte_carlo_sensitivity(rig_scores, centered=False)

    fig, axs = plt.subplots(2, 2, figsize=(11, 8.5))

    ax = axs[0, 0]
    vals = [illus_base[m] for m in MODEL_NAMES]
    ax.bar(MODEL_NAMES, vals, color=[colors[m] for m in MODEL_NAMES])
    for i, v in enumerate(vals):
        ax.text(i, v + 1, f"{v:.1f}", ha="center", fontsize=9)
    ax.set_ylim(0, 80)
    ax.set_ylabel("Weighted total score")
    ax.set_title("A. Baseline score -- illustrative\nexpert-judgment qualitative criteria")

    ax = axs[0, 1]
    vals = [rig_base[m] for m in MODEL_NAMES]
    ax.bar(MODEL_NAMES, vals, color=[colors[m] for m in MODEL_NAMES])
    for i, v in enumerate(vals):
        ax.text(i, v + 1, f"{v:.1f}", ha="center", fontsize=9)
    ax.set_ylim(0, 80)
    ax.set_title("B. Baseline score -- rigorous,\nformula-derived qualitative criteria")

    x = np.arange(2)
    width = 0.25
    scenarios = ["Centered on\noriginal weights", "Fully uniform\nweights"]

    ax = axs[1, 0]
    for i, m in enumerate(MODEL_NAMES):
        v = [illus_mc_centered[m], illus_mc_uniform[m]]
        ax.bar(x + (i - 1) * width, v, width, label=m.capitalize(), color=colors[m])
    ax.set_xticks(x)
    ax.set_xticklabels(scenarios)
    ax.set_ylabel("Win rate (%), 20,000 trials")
    ax.set_title("C. Monte Carlo win rate -- illustrative\nqualitative criteria")
    ax.legend(fontsize=8)

    ax = axs[1, 1]
    for i, m in enumerate(MODEL_NAMES):
        v = [rig_mc_centered[m], rig_mc_uniform[m]]
        ax.bar(x + (i - 1) * width, v, width, label=m.capitalize(), color=colors[m])
    ax.set_xticks(x)
    ax.set_xticklabels(scenarios)
    ax.set_title("D. Monte Carlo win rate -- rigorous,\nformula-derived qualitative criteria")
    ax.legend(fontsize=8)

    fig.suptitle(
        "The weighted decision matrix ranking is sensitive to how qualitative criteria\n"
        "(clinical applicability, ease of parameter estimation, model stability) are operationalized",
        fontsize=11.5, y=1.01,
    )
    fig.tight_layout()

    out_path = os.path.join(OUT_DIR, "fig_sensitivity_comparison.png")
    fig.savefig(out_path, dpi=200, bbox_inches="tight")
    print(f"Saved {out_path}")

    print("\nIllustrative baseline:", {k: round(v, 1) for k, v in illus_base.items()})
    print("Rigorous baseline:    ", {k: round(v, 1) for k, v in rig_base.items()})
    print("Illustrative MC (centered/uniform):", illus_mc_centered, illus_mc_uniform)
    print("Rigorous MC (centered/uniform):    ", rig_mc_centered, rig_mc_uniform)


if __name__ == "__main__":
    main()
