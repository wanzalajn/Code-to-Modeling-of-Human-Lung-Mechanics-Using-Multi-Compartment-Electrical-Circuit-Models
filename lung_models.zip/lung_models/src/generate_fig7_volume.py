"""
Generate Figure 7: comparative simulated volume-time (V-t) curves for the
single-, two-, three-, and multi-compartment (N=10) lung models under
volume-controlled ventilation.

Usage:
    python generate_fig7_volume.py

Output:
    ../figures/fig7_volume_time.png
"""

import os
import matplotlib.pyplot as plt
import matplotlib as mpl

from simulate import simulate_all, TI, T_HOLD, T_CYCLE, VT

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

mpl.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.edgecolor": "0.3", "axes.grid": True,
    "grid.color": "0.85", "grid.linewidth": 0.6,
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
})


def main():
    results = simulate_all()

    fig, ax = plt.subplots(figsize=(8, 5.5))
    colors = {"single": "black", "two": "#1f77b4", "three": "#d85a30", "multi": "#639922"}
    labels = {"single": "Single-compartment", "two": "Two-compartment",
              "three": "Three-compartment", "multi": "Multi-compartment (N=10)"}

    for name in ["single", "two", "three", "multi"]:
        res = results[name]
        ax.plot(res["t"], res["V"] * 1000.0, color=colors[name], lw=1.8, label=labels[name])

    ax.axhline(VT * 1000.0, color="gray", lw=0.9, ls=":")
    ax.text(T_CYCLE * 0.02, VT * 1000.0 + 8, f"Tidal volume = {VT * 1000:.0f} mL", fontsize=9, color="0.3")
    ax.axvline(TI, color="0.5", lw=0.8, ls="-.")
    ax.axvline(TI + T_HOLD, color="0.5", lw=0.8, ls="-.")

    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Volume above FRC (mL)")
    ax.set_xlim(0, T_CYCLE)
    ax.set_ylim(0, 560)
    ax.set_title("Comparative simulated volume-time (V-t) curves\n"
                 f"under volume-controlled ventilation (tidal volume = {VT * 1000:.0f} mL)")
    ax.legend(loc="upper right", fontsize=9)

    fig.tight_layout()
    out_path = os.path.join(OUT_DIR, "fig7_volume_time.png")
    fig.savefig(out_path, dpi=200)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
