"""
Weighted decision matrix and sensitivity analysis for model selection
among the single-, two-, and three-compartment models (Section IV-I/IV-J
of the manuscript).

The multi-compartment (N=10) model is excluded from this competitive
ranking because it is used as the internal reference model against which
the other models' predictive accuracy is measured; scoring it for
accuracy against itself would be circular.

Two of the five decision-matrix criteria (Predictive Accuracy,
Computational Speed) are computed directly from simulation results. The
remaining three (Clinical Applicability, Ease of Parameter Estimation,
Model Stability) are qualitative; this script computes them two ways
("illustrative" expert-judgment scores, and "rigorous" formula-derived
proxy scores) so that the sensitivity of the final ranking to this
choice can be seen directly. See the manuscript, Section IV-J, for the
full discussion of both schemes and their limitations.

Usage:
    python sensitivity_analysis.py
"""

import numpy as np
from simulate import MODELS

MODEL_NAMES = ["single", "two", "three"]

# ----------------------------------------------------------------------
# Quantitative criteria (computed directly from manuscript Tables III/IV)
# ----------------------------------------------------------------------
RMSE = {"single": 0.207, "two": 0.205, "three": 0.203}
SIM_TIME_MS = {"single": 1.8, "two": 3.6, "three": 6.4}

BASE_WEIGHTS = {
    "accuracy": 0.35,
    "speed": 0.25,
    "clin_app": 0.20,
    "param_est": 0.10,
    "stability": 0.10,
}
CRITERIA = list(BASE_WEIGHTS.keys())


def minmax_score(d, lower_is_better=True):
    """Normalize a dict of raw values to a 0-100 score."""
    vals = list(d.values())
    lo, hi = min(vals), max(vals)
    if hi == lo:
        return {k: 100.0 for k in d}
    if lower_is_better:
        return {k: 100.0 * (hi - v) / (hi - lo) for k, v in d.items()}
    return {k: 100.0 * (v - lo) / (hi - lo) for k, v in d.items()}


# ----------------------------------------------------------------------
# Scheme 1: illustrative expert-judgment scores for the qualitative criteria
# ----------------------------------------------------------------------
ILLUSTRATIVE_CLIN_APP = {"single": 60, "two": 75, "three": 90}
ILLUSTRATIVE_PARAM_EST = {"single": 95, "two": 80, "three": 65}
ILLUSTRATIVE_STABILITY = {"single": 95, "two": 90, "three": 85}


# ----------------------------------------------------------------------
# Scheme 2: formula-derived proxy scores for the qualitative criteria
# ----------------------------------------------------------------------
def state_matrix(r, c, r0):
    """Linear state matrix A for dV/dt = A V + B*Pao(t), derived from the
    branching-pressure algebra of manuscript Sections IV-C/IV-D."""
    r = np.asarray(r, dtype=float)
    c = np.asarray(c, dtype=float)
    k = len(r)
    a = np.zeros((k, k))
    s1 = np.sum(1.0 / r)
    denom = 1.0 + r0 * s1
    for i in range(k):
        for j in range(k):
            a[i, j] = (r0 / (r[i] * denom)) * (1.0 / (r[j] * c[j]))
        a[i, i] -= 1.0 / (r[i] * c[i])
    return a


# Structural free-parameter counts, from the GENERAL model definitions in
# Sections IV-B-IV-E (single: R,C; two: R1,C1,R2,C2, no shared R0 per
# Section IV-C; three: R0,R1,C1,R2,C2,R3,C3 per Section IV-D). This is
# deliberately NOT derived from the specific reduced-order MODELS instances
# used for simulation (which fold R0 into the aggregated R_i for the
# coarse-graining exercise in Section II-D) -- ease of parameter
# estimation is a property of the model structure a clinician would need
# to identify in general, not an artifact of this particular numerical
# experiment's parameterization.
STRUCTURAL_N_PARAMS = {"single": 2, "two": 4, "three": 7}


def compute_rigorous_scores():
    stiffness, cv = {}, {}
    for name in MODEL_NAMES:
        m = MODELS[name]
        r, c, r0 = m["R"], m["C"], m["R0"]

        a = state_matrix(r, c, r0)
        eigs = np.linalg.eigvals(a)
        mags = np.abs(eigs.real)
        stiffness[name] = float(mags.max() / mags.min())

        tau = np.asarray(r) * np.asarray(c)
        cv[name] = float(np.std(tau) / np.mean(tau)) if len(tau) > 1 else 0.0

    n_params = dict(STRUCTURAL_N_PARAMS)
    return stiffness, n_params, cv


def build_scores(scheme):
    """Return {criterion: {model: score_0_to_100}} for the requested scheme
    ("illustrative" or "rigorous")."""
    accuracy = minmax_score(RMSE, lower_is_better=True)
    speed = minmax_score(SIM_TIME_MS, lower_is_better=True)

    if scheme == "illustrative":
        clin_app = dict(ILLUSTRATIVE_CLIN_APP)
        param_est = dict(ILLUSTRATIVE_PARAM_EST)
        stability = dict(ILLUSTRATIVE_STABILITY)
    elif scheme == "rigorous":
        stiffness, n_params, cv = compute_rigorous_scores()
        stability = minmax_score(stiffness, lower_is_better=True)
        param_est = minmax_score(n_params, lower_is_better=True)
        clin_app = minmax_score(cv, lower_is_better=False)
    else:
        raise ValueError(f"unknown scheme: {scheme}")

    return {
        "accuracy": accuracy,
        "speed": speed,
        "clin_app": clin_app,
        "param_est": param_est,
        "stability": stability,
    }


def weighted_totals(scores, weights):
    return {m: sum(weights[c] * scores[c][m] for c in weights) for m in MODEL_NAMES}


def one_at_a_time_sensitivity(scores, delta=0.10):
    """For each criterion, perturb its weight by +/-delta (rescaling the
    remaining weights proportionally) and report the winning model."""
    rows = []
    for c in CRITERIA:
        for sign in (-1, +1):
            w = dict(BASE_WEIGHTS)
            new_c = max(0.0, w[c] + sign * delta)
            remaining = 1.0 - new_c
            other_sum = sum(w[k] for k in CRITERIA if k != c)
            for k in CRITERIA:
                if k != c:
                    w[k] = w[k] / other_sum * remaining
            w[c] = new_c
            totals = weighted_totals(scores, w)
            winner = max(totals, key=totals.get)
            rows.append((c, sign * delta, totals, winner))
    return rows


def monte_carlo_sensitivity(scores, n_trials=20000, centered=True, seed=42):
    """Sample random weight vectors and report the win rate of each model.

    If centered=True, weights are sampled from a Dirichlet distribution
    concentrated around BASE_WEIGHTS. If False, weights are drawn from a
    fully uniform Dirichlet distribution (no prior assumption at all).
    """
    rng = np.random.default_rng(seed)
    if centered:
        alpha = np.array([BASE_WEIGHTS[c] for c in CRITERIA]) * 10
    else:
        alpha = np.ones(len(CRITERIA))
    samples = rng.dirichlet(alpha, size=n_trials)

    wins = {m: 0 for m in MODEL_NAMES}
    for row in samples:
        w = {c: row[i] for i, c in enumerate(CRITERIA)}
        totals = weighted_totals(scores, w)
        wins[max(totals, key=totals.get)] += 1
    return {m: 100.0 * wins[m] / n_trials for m in MODEL_NAMES}


def main():
    for scheme in ("illustrative", "rigorous"):
        print(f"\n{'=' * 70}\nScheme: {scheme}\n{'=' * 70}")
        scores = build_scores(scheme)
        for c, d in scores.items():
            print(f"  {c:10s}:", {k: round(v, 2) for k, v in d.items()})

        base = weighted_totals(scores, BASE_WEIGHTS)
        print(f"\n  Baseline weighted totals: "
              f"{ {k: round(v, 2) for k, v in base.items()} }")
        print(f"  Baseline winner: {max(base, key=base.get)}")

        print("\n  One-at-a-time weight perturbation (+/-10 percentage points):")
        for c, delta, totals, winner in one_at_a_time_sensitivity(scores):
            print(f"    {c:10s} {delta:+.2f}: "
                  f"{ {k: round(v, 1) for k, v in totals.items()} } -> winner: {winner}")

        centered = monte_carlo_sensitivity(scores, centered=True)
        uniform = monte_carlo_sensitivity(scores, centered=False)
        print(f"\n  Monte Carlo win rate, centered on original weights: "
              f"{ {k: round(v, 1) for k, v in centered.items()} }")
        print(f"  Monte Carlo win rate, fully uniform weights:        "
              f"{ {k: round(v, 1) for k, v in uniform.items()} }")


if __name__ == "__main__":
    main()
