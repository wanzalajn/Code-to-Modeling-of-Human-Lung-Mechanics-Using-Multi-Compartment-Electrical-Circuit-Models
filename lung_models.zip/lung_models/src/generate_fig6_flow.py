"""
Generate Figure 6: comparative simulated flow-time (Q-t) curves for the
single-, two-, three-, and multi-compartment (N=10) lung models under
volume-controlled ventilation.

Usage:
    python generate_fig6_flow.py

Output:
    ../figures/fig6_flow_time.png
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

from simulate import MODELS, simulate_all, N_MULTI, TI, T_HOLD, T_CYCLE

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

mpl.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.edgecolor": "0.3", "axes.grid": True,
    "grid.color": "0.85", "grid.linewidth": 0.6,
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "axes.labelsize": 10, "legend.fontsize": 8, "legend.framealpha": 0.9,
    "lines.linewidth": 1.6,
})


def main():
    results = simulate_all()

    fig, axs = plt.subplots(2, 2, figsize=(11, 8.5))
    panel_titles = {
        "single": "A. Single-compartment model",
        "two": "B. Two-compartment model",
        "three": "C. Three-compartment model",
        "multi": "D. Multi-compartment (N=10) model",
    }
    colors10 = plt.cm.viridis(np.linspace(0, 0.9, N_MULTI))

    for ax, name in zip(axs.flat, ["single", "two", "three", "multi"]):
        res = results[name]
        tt = res["t"]

        ax.plot(tt, res["Q"] * 60.0, color="black", lw=2.0, label="Total airflow $\\dot V(t)$")

        if name == "two":
            for i in range(2):
                ax.plot(tt, res["Qi"][:, i] * 60.0, lw=1.2, ls="--", label=f"$Q_{{{i + 1}}}(t)$")
        elif name == "three":
            for i in range(3):
                ax.plot(tt, res["Qi"][:, i] * 60.0, lw=1.2, ls="--", label=f"$Q_{{{i + 1}}}(t)$")
        elif name == "multi":
            for i in range(N_MULTI):
                ax.plot(tt, res["Qi"][:, i] * 60.0, lw=0.8, color=colors10[i], alpha=0.75)

        ax.axhline(0, color="gray", lw=0.8)
        ax.axvline(TI, color="0.5", lw=0.8, ls="-.")
        ax.axvline(TI + T_HOLD, color="0.5", lw=0.8, ls="-.")

        ax.set_title(panel_titles[name])
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Airflow (L/min)")
        ax.set_xlim(0, T_CYCLE)
        ax.set_ylim(-40, 40)
        ax.legend(loc="upper right", fontsize=7)

    fig.suptitle(
        "Comparative simulated flow-time (Q-t) curves under volume-controlled ventilation\n"
        "(constant inspiratory flow = 30 L/min, passive expiration to PEEP = 5 cmH$_2$O)",
        fontsize=11, y=0.995,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.96])

    out_path = os.path.join(OUT_DIR, "fig6_flow_time.png")
    fig.savefig(out_path, dpi=200)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
