"""
Generate Figure 8: comparative dynamic compliance-resistance (Cdyn-Raw)
response for the single-, two-, three-, and multi-compartment (N=10) lung
models, using the classical frequency-dependence-of-compliance relationship
of Otis et al. (1956): Cdyn = C / sqrt(1 + (2*pi*f*R*C)^2).

Usage:
    python generate_fig8_compliance.py

Output:
    ../figures/fig8_compliance_resistance.png
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl

from simulate import MODELS, N_MULTI, T_CYCLE

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "figures")
os.makedirs(OUT_DIR, exist_ok=True)

mpl.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white",
    "axes.edgecolor": "0.3", "axes.grid": True,
    "grid.color": "0.85", "grid.linewidth": 0.6,
    "font.size": 10, "axes.titlesize": 11, "axes.titleweight": "bold",
    "legend.fontsize": 8,
})


def dynamic_compliance(c, r, f):
    """Otis et al. (1956) frequency-dependence-of-compliance relationship."""
    omega = 2 * np.pi * f
    return c / np.sqrt(1.0 + (omega * r * c) ** 2)


def main():
    f_breath = 1.0 / T_CYCLE
    raw_sweep = np.linspace(0.5, 30, 300)

    fig, axs = plt.subplots(2, 2, figsize=(11, 8.5))
    panel_titles = {
        "single": "A. Single-compartment model",
        "two": "B. Two-compartment model",
        "three": "C. Three-compartment model",
        "multi": "D. Multi-compartment (N=10) model",
    }
    colors10 = plt.cm.viridis(np.linspace(0, 0.9, N_MULTI))

    for ax, name in zip(axs.flat, ["single", "two", "three", "multi"]):
        m = MODELS[name]
        cs = m["C"]
        labels = m["labels"]

        if name == "multi":
            for i, c in enumerate(cs):
                ax.plot(raw_sweep, dynamic_compliance(c, raw_sweep, f_breath) * 1000,
                        lw=0.9, color=colors10[i], alpha=0.8)
            ax.text(0.97, 0.93, f"{N_MULTI} compartments\n(wide dispersion)",
                    transform=ax.transAxes, ha="right", va="top", fontsize=8, color="0.3")
        else:
            for c, lab in zip(cs, labels):
                ax.plot(raw_sweep, dynamic_compliance(c, raw_sweep, f_breath) * 1000, lw=1.6, label=lab)
            ax.legend(loc="upper right", fontsize=8)

        ax.set_title(panel_titles[name])
        ax.set_xlabel("Airway resistance, $R_{aw}$ (cmH$_2$O/L/s)")
        ax.set_ylabel("Dynamic compliance, $C_{dyn}$ (mL/cmH$_2$O)")
        ax.set_xlim(0, 30)
        ax.set_ylim(0, 70)

    fig.suptitle(
        "Comparative dynamic compliance-resistance ($C_{dyn}-R_{aw}$) response,\n"
        r"$C_{dyn}=C/\sqrt{1+(2\pi f R C)^2}$ at breathing frequency $f=$"
        f"{f_breath * 60:.0f} breaths/min (Otis et al., 1956)",
        fontsize=11, y=0.995,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.94])

    out_path = os.path.join(OUT_DIR, "fig8_compliance_resistance.png")
    fig.savefig(out_path, dpi=200)
    print(f"Saved {out_path}")


if __name__ == "__main__":
    main()
