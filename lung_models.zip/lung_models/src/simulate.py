"""
lung_models.simulate
=====================

Core simulation engine for the single-, two-, three-, and multi-compartment
(N=10) electrical-analog lung models described in the manuscript
"Modeling and Simulation of Human Lung Mechanics Using Single to
Multi-Compartment Electrical Circuit Models".

No patient or clinical data are used anywhere in this module. The
multi-compartment (N=10) model is treated as an internal, high-fidelity
analytical reference; the single-, two-, and three-compartment models are
obtained by coarse-graining (parallel aggregation of resistance, summation
of compliance) contiguous groups of the ten reference compartments, so
that they are nested approximations of the same underlying reference
lung rather than independently chosen parameter sets.

Ventilation is simulated as true volume-controlled ventilation (VCV):
  * Inspiration: constant prescribed flow (flow-generator boundary
    condition).
  * Inspiratory hold: zero external flow (occlusion), but compartments
    may still redistribute volume internally ("pendelluft").
  * Expiration: passive, pressure-controlled boundary condition at PEEP
    (the expiratory valve opens to a fixed pressure, and flow is
    whatever the circuit's own R/C dynamics produce).

Units: pressure in cmH2O, resistance in cmH2O/L/s, compliance in L/cmH2O,
volume in L, flow in L/s, time in seconds, unless stated otherwise.
"""

import numpy as np

# ---------------------------------------------------------------------
# Reference (N=10) model and coarse-grained reduced-order models
# ---------------------------------------------------------------------

N_MULTI = 10
RI_MULTI = np.linspace(8.0, 30.0, N_MULTI)      # cmH2O/L/s
CI_MULTI = np.linspace(0.008, 0.003, N_MULTI)   # L/cmH2O
R0_REF = 1.0                                    # common proximal resistance of the reference model

_RTOT_REF = R0_REF + RI_MULTI  # total series resistance of each reference branch


def _aggregate(index_groups):
    """Parallel-combine resistance and sum compliance within each group of
    reference compartments, returning (R_list, C_list) for the reduced
    model. This is the coarse-graining procedure described in Section
    II-D of the manuscript."""
    Rs, Cs = [], []
    for grp in index_groups:
        grp = np.asarray(grp)
        Rs.append(float(1.0 / np.sum(1.0 / _RTOT_REF[grp])))
        Cs.append(float(np.sum(CI_MULTI[grp])))
    return Rs, Cs


_R_SINGLE, _C_SINGLE = _aggregate([np.arange(0, 10)])
_R_TWO, _C_TWO = _aggregate([np.arange(0, 5), np.arange(5, 10)])
_R_THREE, _C_THREE = _aggregate([np.arange(0, 4), np.arange(4, 7), np.arange(7, 10)])

MODELS = {
    "single": dict(
        R=_R_SINGLE, C=_C_SINGLE, R0=0.0,
        labels=["Single compartment (aggregate of all 10 reference units)"],
    ),
    "two": dict(
        R=_R_TWO, C=_C_TWO, R0=0.0,
        labels=["Compartment 1 (aggregate of reference units 1-5)",
                "Compartment 2 (aggregate of reference units 6-10)"],
    ),
    "three": dict(
        R=_R_THREE, C=_C_THREE, R0=0.0,
        labels=["Compartment 1 (aggregate of reference units 1-4)",
                "Compartment 2 (aggregate of reference units 5-7)",
                "Compartment 3 (aggregate of reference units 8-10)"],
    ),
    "multi": dict(
        R=list(RI_MULTI), C=list(CI_MULTI), R0=R0_REF,
        labels=[f"Reference compartment {i + 1}" for i in range(N_MULTI)],
    ),
}

# NOTE: R0 is 0.0 for all three reduced-order models (single/two/three)
# because the common proximal resistance R0 of the reference model is
# already folded into their aggregated branch resistances via _RTOT_REF
# = R0_REF + Ri during coarse-graining (see _aggregate above); setting a
# nonzero R0 again for these models would double-count it. Only the
# "multi" (N=10) reference model carries an explicit, separate R0.

# ---------------------------------------------------------------------
# Ventilation waveform (volume-controlled ventilation) parameters
# ---------------------------------------------------------------------

TI = 1.0           # s, inspiratory flow phase
T_HOLD = 0.3        # s, inspiratory pause (breath-hold)
TE = 3.7           # s, expiratory phase
T_CYCLE = TI + T_HOLD + TE   # 5.0 s total (one full breath)
PEEP = 5.0          # cmH2O
VT = 0.5            # L, target tidal volume (~7 mL/kg for a 70 kg adult)
Q0 = VT / TI        # L/s, constant inspiratory flow (= 30 L/min)
DT = 0.0005         # s, integration step size


def simulate(model, dt=DT, t_cycle=T_CYCLE, ti=TI, t_hold=T_HOLD, peep=PEEP, q0=Q0):
    """
    Simulate one full breath of volume-controlled ventilation for a given
    compartment model.

    Parameters
    ----------
    model : dict
        A model specification with keys "R" (list of resistances,
        cmH2O/L/s), "C" (list of compliances, L/cmH2O), and "R0" (common
        proximal resistance, cmH2O/L/s; 0.0 if none).

    Returns
    -------
    dict with keys:
        t    : time vector (s)
        Pao  : airway opening pressure, absolute (cmH2O)
        Q    : total airflow (L/s)
        V    : total volume above FRC (L)
        Vi   : per-compartment volume (L), shape (n, k)
        Qi   : per-compartment flow (L/s), shape (n, k)
        Pi   : per-compartment pressure relative to PEEP (cmH2O), shape (n, k)
        R, C, R0 : the model parameters used
    """
    R = np.array(model["R"])
    C = np.array(model["C"])
    R0 = model["R0"]
    k = len(R)

    t = np.arange(0.0, t_cycle + dt, dt)
    n = len(t)

    V = np.zeros((n, k))
    Qi = np.zeros((n, k))
    Pao_rel = np.zeros(n)
    Q_total = np.zeros(n)

    inv_r = 1.0 / R

    for idx in range(1, n):
        tt = t[idx]
        v_prev = V[idx - 1, :]

        if tt <= ti:
            # Phase A: constant-flow inspiration (flow-generator boundary condition)
            q_tot_now = q0
            pb = (q_tot_now + np.sum(v_prev / (R * C))) / np.sum(inv_r)
            q_now = (pb - v_prev / C) / R
            pao_now = pb + R0 * q_tot_now

        elif tt <= ti + t_hold:
            # Phase B: inspiratory hold (occlusion; internal redistribution allowed)
            q_tot_now = 0.0
            pb = (q_tot_now + np.sum(v_prev / (R * C))) / np.sum(inv_r)
            q_now = (pb - v_prev / C) / R
            pao_now = pb + R0 * q_tot_now

        else:
            # Phase C: passive expiration (pressure boundary condition at PEEP)
            pao_now = 0.0  # relative to PEEP
            pb = (pao_now + R0 * np.sum(v_prev / (R * C))) / (1.0 + R0 * np.sum(inv_r))
            q_now = (pb - v_prev / C) / R
            pao_now = pb + R0 * np.sum(q_now)

        V[idx, :] = v_prev + q_now * dt
        Qi[idx, :] = q_now
        Pao_rel[idx] = pao_now
        Q_total[idx] = np.sum(q_now)

    p_i = V / C
    pao_abs = Pao_rel + peep

    return dict(
        t=t, Pao=pao_abs, Q=Q_total, V=np.sum(V, axis=1),
        Vi=V, Qi=Qi, Pi=p_i, R=R, C=C, R0=R0,
    )


def simulate_all(models=None, **kwargs):
    """Simulate every model in `models` (default: all of MODELS) and
    return a dict of results keyed by model name."""
    if models is None:
        models = MODELS
    return {name: simulate(spec, **kwargs) for name, spec in models.items()}


if __name__ == "__main__":
    # Quick sanity check when run directly: python -m lung_models.simulate
    results = simulate_all()
    for name, res in results.items():
        plateau_idx = int((TI + T_HOLD / 2) / DT)
        print(
            f"{name:6s}: peak Pao={res['Pao'].max():.2f} cmH2O, "
            f"plateau Pao={res['Pao'][plateau_idx]:.2f} cmH2O, "
            f"tidal volume={res['V'].max() * 1000:.0f} mL"
        )
