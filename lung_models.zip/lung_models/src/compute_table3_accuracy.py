"""
Generate the predictive-accuracy comparison in Table III: RMSE, MAE, and
Pearson correlation coefficient of the single-, two-, and three-compartment
models' airway opening pressure Pao(t) against that of the multi-compartment
(N=10) reference model.

No patient or clinical data are used; this is an internal model-order
approximation comparison (see manuscript Section II-D).

Usage:
    python compute_table3_accuracy.py
"""

import numpy as np
from simulate import simulate_all


def rmse(y, yhat):
    return float(np.sqrt(np.mean((y - yhat) ** 2)))


def mae(y, yhat):
    return float(np.mean(np.abs(y - yhat)))


def pearson_corr(y, yhat):
    if np.std(y) == 0 or np.std(yhat) == 0:
        return 1.0
    return float(np.corrcoef(y, yhat)[0, 1])


def main():
    results = simulate_all()
    reference = results["multi"]["Pao"]

    print(f"{'Model':<12}{'RMSE':>10}{'MAE':>10}{'Correlation':>14}")
    for name in ["single", "two", "three", "multi"]:
        y_hat = results[name]["Pao"]
        print(f"{name:<12}{rmse(reference, y_hat):>10.3f}{mae(reference, y_hat):>10.3f}"
              f"{pearson_corr(reference, y_hat):>14.4f}")


if __name__ == "__main__":
    main()
